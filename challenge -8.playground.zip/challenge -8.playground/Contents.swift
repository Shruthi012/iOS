import UIKit
struct Car {

    var make : String = "benz"
    var model : String = "GLC"
    let prefix = "2019"
    var messageWithPrefix :String{
     return (prefix + make + model)
    }
    
func getdetails () {
    
   print(messageWithPrefix)
    
}
}

