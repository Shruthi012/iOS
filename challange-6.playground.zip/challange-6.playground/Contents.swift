import UIKit
// 4 people have dinner and want to split bill .calculate total with tax and how much each person owes.
let people:Double = 4
let subtotal:Double = 128
let tax = 0.13
var split:Double = (subtotal+tax)/people
print (split)





