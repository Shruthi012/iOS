import UIKit
import Darwin
func greet() {
    print("Good Morning !")
}
greet()



//challange -2//

func printTotalWithTax(subtotal:Double) -> Double {
    return(subtotal * 1.13)
}
print(printTotalWithTax(subtotal: 128))


//challange -3//


func getTotalWithTax(subtotal:Double) -> Double {
    return(subtotal * 1.13)
    
}
let subtotal = 128
let result = getTotalWithTax(subtotal: 128)
print(result)



//Challange -4 //

func calculateTotalWithTax(subtotal:Double ,tax:Double)-> Double{
    return(subtotal * tax)
}

let subtotal = 128
let tax = 1.13
let result = calculateTotalWithTax(subtotal: 0, tax: 0)
print(result )



